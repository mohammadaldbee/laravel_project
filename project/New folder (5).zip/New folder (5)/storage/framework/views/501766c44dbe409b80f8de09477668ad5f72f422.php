




<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>RegistrationForm_v9 by Colorlib</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- LINEARICONS -->
		<link rel="stylesheet" href="regis/fonts/linearicons/style.css">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="regis/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

		<!-- DATE-PICKER -->
		<link rel="stylesheet" href="regis/vendor/date-picker/css/datepicker.min.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="regis/css/style.css">
	</head>

	<body>

        <!-- Session Status -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

		<div class="wrapper">
			<div class="inner">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                     <h3>Log In</h3>
					<div class="form-row">
						<div class="form-wrapper">
							<label for="email" :value="__('Email')">Email *</label>
							<input type="email" name="email" id="email" class="form-control" placeholder="Your Email" :value="old('email')" required>
						</div>
					</div>
					<div class="form-row">
						<div class="form-wrapper">
							<label for="passward" :value="__('Password')">Password *</label>
							<input  class="form-control" id="password" 
							type="password"
							placeholder="Your password"
							name="password"
							required autocomplete="current-password">
						</div>
						
					</div>
					
					
					
					
                     <!-- Remember Me -->
            <div class="block mt-4">
                <label for="remember_me" class="inline-flex items-center">
                    <input id="remember_me" type="checkbox" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" name="remember">
                    <span class="ml-2 text-sm text-gray-600"><?php echo e(__('Remember me')); ?></span>
                </label>
            </div>


            
					<button data-text="Click Now">
						<span><?php echo e(__('Log in')); ?></span>
					</button>

                    <div class="flex items-center justify-end mt-4">
                        <?php if(Route::has('password.request')): ?>
                            <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">
                                <?php echo e(__('Forgot your password?')); ?>

                            </a>
                        <?php endif; ?>
				</form>
			</div>
		</div>
		
		<script src="regis/js/jquery-3.3.1.min.js"></script>

		<!-- DATE-PICKER -->
		<script src="regis/vendor/date-picker/js/datepicker.js"></script>
		<script src="regis/vendor/date-picker/js/datepicker.en.js"></script>

		<script src="regis/js/main.js"></script>
	</body>
</html><?php /**PATH C:\xampp\htdocs\laravel-restaurant-reservation-main\resources\views/auth/login.blade.php ENDPATH**/ ?>