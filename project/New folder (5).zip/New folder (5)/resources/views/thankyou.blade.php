<x-guest-layout>
    <div class="container w-full px-5 py-6 mx-auto">
        <h1>Thank you</h1>
        <p>You reservation is ready.</p>
    </div>

<br>
        <a href="{{ route('orders1.index') }}"

        class="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg text-white">Make order</a>
    </div>
</x-guest-layout>